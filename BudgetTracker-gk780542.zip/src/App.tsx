import { createDrawerNavigator } from '@react-navigation/drawer';
import { createStaticNavigation, useNavigation } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import React, { useEffect, useState } from 'react';
import { Image, Linking, ScrollView, StyleSheet, Text, TextInput, TouchableOpacity, View } from 'react-native';
import 'react-native-gesture-handler';

import {
  SQLiteProvider,
  useSQLiteContext,
  type SQLiteDatabase,
} from 'expo-sqlite';

const expenseImg = require('../assets/images/expenses.webp');

interface ExpenseEntity {

  id: number;
  amount: string;
  purpose: string;
  category: string;
  expenseDate: string;
}

const theAmount = 0;

function Home() {
  const navigation = useNavigation<any>();
  const db = useSQLiteContext();
  
  

  const [expenses, setExpenses] = useState<ExpenseEntity[]>([]);

  const [lastAmount, setLastAmount] = useState('0.00');

  async function loadExpenses() {

  try {
    const result = await db.getAllAsync<ExpenseEntity>(
      'SELECT id, amount, purpose, category, expenseDate FROM expenses ORDER BY id DESC'
    );

    setExpenses(result);

    if (result.length > 0) {

      setLastAmount(result[0].amount);
    } else {

      setLastAmount('0.00');
    }
  } catch (error) {
    console.log('Error loading expenses');
  
    
  }
}

  useEffect(() => {

    const unsubscribe = navigation.addListener('focus', () => {
      loadExpenses();
    });

    return unsubscribe;
  }, [navigation]);

  return (
    
    <View style={styles.container}>
      <View style={styles.amountBar}>
        <Text style={styles.lastAmountSpended}>Last Amount Spended</Text>
        <Text style={styles.amountValue}>${lastAmount}</Text>
      </View>

      <TouchableOpacity
        style={styles.addExpends}
        onPress={() => navigation.navigate('AddExpenses')}
      >
        <Text style={styles.buttonText}>Add Expenses</Text>
      </TouchableOpacity>

      <Text style={styles.expensesTitle}>Expenses</Text>

      <ScrollView>
        <View style={styles.mainScroll}>
        {expenses.map((item) => (
          <View key={item.id} style={styles.expenseRow}>
            <Image source={expenseImg} style={styles.expenseImage} />

            <View style={styles.infoBox}>
              <Text style={styles.amountText}>${item.amount}</Text>
              <Text>{item.category}</Text>
            </View>

            <View>
              <TouchableOpacity
                onPress={() =>
                  navigation.navigate('Details', {
                    amount: item.amount,
                    purpose: item.purpose,
                    category: item.category,
                    date: item.expenseDate,
                  })
                }
              >
                <Text style={styles.detailsText}>View Details</Text>
              </TouchableOpacity>

              <Text>{item.expenseDate}</Text>
            </View>
          </View>
        ))}
        </View>
      </ScrollView>
    </View>
  );
}

function isValidDate(dateText: string) {

  const parts = dateText.split('/');

  if (parts.length !== 3) {
    return false;
  }

  const month = Number(parts[0]);

  const day = Number(parts[1]);

  const year = Number(parts[2]);

  if (isNaN(month) || isNaN(day) || isNaN(year)) {
    return false;
  }

  if (year < 1900 || year > 2100) {

    return false;
  }

  const realDate = new Date(year, month - 1, day);

  if (realDate.getFullYear() !== year) {

    return false;
  }

  if (realDate.getMonth() !== month - 1) {

    return false;
  }

  if (realDate.getDate() !== day) {
    return false;
  }

  return true;
}
function AddExpenses() {
  const navigation = useNavigation();

  const db = useSQLiteContext();

  const [amount, setAmount] = useState('');
  const [purpose, setPurpose] = useState('');
  const [category, setCategory] = useState('');
  const [date, setDate] = useState('');
  const [errorMessage, setErrorMessage] = useState('');
 
  

  const [expenses, setExpenses] = useState<ExpenseEntity[]>([]);

  const [lastAmount, setLastAmount] = useState('0.00');

  async function loadExpenses() {
  try {
    const result = await db.getAllAsync<ExpenseEntity>(
      'SELECT id, amount, purpose, category, expenseDate FROM expenses ORDER BY id DESC'
    );

    setExpenses(result);

    if (result.length > 0) {
      setLastAmount(result[0].amount);
    } else {
      setLastAmount('0.00');
    }
  } catch (error) {
    console.log('Error loading expenses');
    
    
  }
}

  useEffect(() => {

    const unsubscribe = navigation.addListener('focus', () => {
      loadExpenses();
    });

    return unsubscribe;
  }, [navigation]);

  async function addExpenseNow() {

    if (amount === '' || purpose === '' || category === '' || date === '') {

      setErrorMessage('Please enter all of the fields.');

      return;
    }

    const amountNumber = Number(amount);

    if (isNaN(amountNumber) || amountNumber <= 0) {

      setErrorMessage('Amount must be a valid number greater than 0.');

      return;
    }

    if (!isValidDate(date)) {

      setErrorMessage('Please enter a real date like this 4/13/2026.');

      return;
    }

    try {
      await db.runAsync(

        'INSERT INTO expenses (amount, purpose, category, expenseDate) VALUES (?, ?, ?, ?)',
        amount,
        purpose,
        category,
        date
      );

      setAmount('');
      setPurpose('');
      setCategory('');
      setDate('');
      setErrorMessage('');

      navigation.navigate('BackHome');
    } catch (error) {

      console.log('Error inserting expense');
     
      setErrorMessage('Expense was not saved.');
    }
  }

  return (
    <View style={styles.container}>
      <View style={styles.amountBar}>
        <Text style={styles.lastAmountSpended}>Last Amount Spended</Text>
        <Text style={styles.amountValue}>${lastAmount}</Text>
      </View>

      <View style={styles.theInputBox}>
        <Text style={styles.pageTitle}>Add Expenses</Text>
        <Text style={styles.subTitle}>Enter your Expense</Text>

        {errorMessage !== '' && (
          <Text style={{ color: 'red', marginBottom: 10 }}>
            {errorMessage}
          </Text>
        )}

        <TextInput
          placeholder="Amount"
          style={styles.input}
          value={amount}
          onChangeText={setAmount}
          keyboardType="numeric"
        />

        <TextInput
          placeholder="Purpose"
          style={styles.input}
          value={purpose}
          onChangeText={setPurpose}
        />

        <TextInput
          placeholder="Category"
          style={styles.input}
          value={category}
          onChangeText={setCategory}
        />

        <TextInput
          placeholder="Date MM/DD/YYYY"
          style={styles.input}
          value={date}
          onChangeText={setDate}
        />

        <TouchableOpacity style={styles.addButton} onPress={addExpenseNow}>
          <Text style={styles.buttonText}>Add</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}
function Details({ route }) {
  let amount = '';
  let purpose = '';
  let category = '';
  let date = '';

  if (route.params) {

    amount = route.params.amount;

    purpose = route.params.purpose;

    category = route.params.category;

    date = route.params.date;
  }

  return (
    <View style={styles.container}>
      <View style={styles.theDetails}>
        <Text style={styles.pageTitle}>Details</Text>

        <View style={styles.detailsBox}>
          <Text style={styles.detailsPageText}>
            Category: <Text style={styles.theText}>{category}</Text>
          </Text>

          <Text style={styles.detailsPageText}>
            Amount: <Text style={styles.theText}>${amount}</Text>
          </Text>

          <Text style={styles.detailsPageText}>
            Purpose: <Text style={styles.theText}>{purpose}</Text>
          </Text>

          <Text style={styles.detailsPageText}>
            Date: <Text style={styles.theText}>{date}</Text>
          </Text>
        </View>
      </View>
    </View>
  );
}

function LearnMore() {

  function openMoneyWebsite() {
    Linking.openURL('https://www.investopedia.com/personal-finance-4427760');
  }

  return (
    <View style={styles.container}>
      <View style={styles.theDetails}>
        <Text style={styles.pageTitle}>Learn About Money</Text>

        <Text style={styles.normalText}>
          This page helps users learn more about money, savings, and budgeting.
        </Text>

        <TouchableOpacity style={styles.addButton} onPress={openMoneyWebsite}>
          <Text style={styles.buttonText}>Open Website</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

function AboutUs() {
  return (
    <View style={styles.container}>
      <View style={styles.theAbout}>
        <Text style={styles.pageTitle}>About Us</Text>

        <Text style={styles.normalText}>
          Budget Tracker is an app that helps people track expenses and manage
          their budget in a simple way.
        </Text>
      </View>
    </View>
  );
}

const Drawer = createDrawerNavigator({
  
  screens: {
    Home: {
      screen: Home,
    },
    'Add Expenses': {
      screen: AddExpenses,
    },
    'Learn About Money': {
      screen: LearnMore,
    },
    'About Us': {
      screen: AboutUs,
    },
  },
});

const RootStack = createNativeStackNavigator({
  screens: {
    BackHome: {
      screen: Drawer,
      options: {
        headerShown: false,
      },
    },
    Details: {
      screen: Details,
      options: {
        title: 'Details',
      },
    },
    AddExpenses: {
      screen: AddExpenses,
      options: {
        title: 'Add Expenses',
      },
    },
  },
});

const Navigation = createStaticNavigation(RootStack);



export default function App() {
  return (
    <SQLiteProvider databaseName="budget.db" onInit={migrateDbIfNeeded}>
      <Navigation />
    </SQLiteProvider>
  );
}

async function migrateDbIfNeeded(db: SQLiteDatabase) {
  await db.execAsync(`
    CREATE TABLE IF NOT EXISTS expenses (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      amount TEXT NOT NULL,
      purpose TEXT NOT NULL,
      category TEXT NOT NULL,
      expenseDate TEXT NOT NULL
    );
  `);
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'white',
    padding: 0,
  },

  amountBar: {
    backgroundColor: 'rgba(246, 110, 205, 0.87)',
    padding: 55,
    borderRadius: 15,
    marginTop: 0,
    marginBottom: 20,

    shadowColor: 'rgb(0, 0, 0)',
    shadowOffset: {
      width: 0,
      height: 5,
    },
    shadowOpacity: 0.99,
    shadowRadius: 6,
    elevation: 9,
  },

  lastAmountSpended: {
    color: 'white',
    fontSize: 14,
    textAlign: 'center',
    fontWeight: "bold",
  },

  amountValue: {
    color: 'white',
    fontSize: 30,
    fontWeight: 'bold',
    textAlign: 'center',
    marginTop: 10,
  },

  addExpends: {
    backgroundColor: 'black',
    padding: 12,
    borderRadius: 20,
    alignItems: 'center',
    alignSelf: 'flex-end',
    width: 140,
    marginBottom: 20,
    marginRight: 20,
    marginTop: 5,
  },

  buttonText: {
    color: 'white',
    fontWeight: 'bold',
  },

  expensesTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 15,
    marginLeft: 20,
  },

  expenseRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 15,
  },

  expenseImage: {
    width: 50,
    height: 50,
    borderRadius: 25,
  },

  infoBox: {
    flex: 1,
    marginLeft: 10,
  },

  amountText: {
    fontWeight: 'bold',
  },

  theDetails: {

    margin: 15,
    marginTop: 50,

  },
  detailsText: {
    fontWeight: 'bold',
  },
  theText: {

    fontWeight: "light",
  },

  pageTitle: {
    fontSize: 22,
    fontWeight: 'bold',
    marginBottom: 10,
  },

  normalText: {
    fontSize: 18,
    lineHeight: 28,
  },

  subTitle: {
    marginBottom: 20,
    color: 'gray',
  },

  theInputBox: {

    margin: 15,
    marginTop: 55,
  },
  input: {
    borderWidth: 1,
    borderColor: '#cccccc',
    borderRadius: 6,
    padding: 10,
    marginBottom: 12,
    fontWeight: "bold",
  },

  addButton: {
    backgroundColor: 'black',
    padding: 12,
    borderRadius: 8,
    alignItems: 'center',
    marginTop: 10,
  },

  detailsBox: {
    marginTop: 40,
  },

  detailsPageText: {
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 10,
  },
  mainScroll: {

    margin: 20,
  },
  theAbout: {

    margin: 15,
  },

});